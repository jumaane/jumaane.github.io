# geobusiness
Test for Google Maps for Business

Notes:
- Google Directions API doesn't support TRANSIT
- Wasn't able to utilize PostGIS (hence couldn't support visits)
- Unsure of offline availability, would use Local Storage if not already using a local GeoJSON object
